#include "../unite/Unite.hpp"
#include "../unite/Tour.hpp"
#include "../unite/Fantassin.hpp"
#include "../unite/Archer.hpp"
#include "../unite/Catapulte.hpp"


#include "../jeu/outils.cpp"
