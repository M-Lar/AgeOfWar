std::string colorMagenta="\033[1;35m";
std::string colorCyan   ="\033[1;36m";
std::string colorGreen   ="\033[1;32m";
//std::string colorMagentaB="\033[1m\033[35m";
std::string colorYellow   ="\033[1;33m";
std::string colorBlack   ="\033[1;90m";
std::string colorReset="\033[0m";
