#include <iostream>
#include <cstdlib>

#include "include.h"


int main(){
  //Jeu jeux;
  Jeu jeux(100, 12, 100, 8); //maxTourJeu Taille pvTour argent
  jeux.jouer();

  return 0;
}
